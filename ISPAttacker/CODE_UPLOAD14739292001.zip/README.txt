This program tests the speed of your internet connection by downloading an animated
GIF picture and mesuring the time it takes.

NOTE:
Remember to erase the cache on your browser if you peform the test more than once 
because it will get the picture from the cache and say you downloaded it VERY quickly.

Created by Martin McCormick
Thanks and vote at PSC!!!