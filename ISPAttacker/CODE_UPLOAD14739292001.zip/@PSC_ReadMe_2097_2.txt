Title: Test Your Internet Connection Speed!
Description: This program tests the speed of your internet connection by downloading an animated
GIF picture and mesuring the time it takes.
NOTE:
Remember to erase the cache on your browser if you peform the test more than once 
because it will get the picture from the cache and say you downloaded it VERY quickly.
Also, please vote! thanks! :-)

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2097&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
