Java Speed Test

PLEASE NOTE: the original SpeedTest.zip was produced with JBuilder 2006
using Java JDK 5.  The current SpeedTest.zip was produced by importing
the original code into IntelliJ IDEA 12 and using Java JDK 6.  The source
code and documentation in the two versions are identical.

The SpeedTest program is used to test the speed of Java code
on various computer platforms.  In preparing for the design of a map
making program I was concerned with how fast, or slow, some common
program code structures might be.  Back in the "old" days when we ran
with a 1MHZ or 2MHZ 8 bit 8080 CPU we always had to be concerned with
getting every bit of performance.  Because Java is a "byte code"
system and not fully compiled it will run somewhat slower than a
fully compiled program.  Comparative tests have shown that the Java
Virtual Machine (VM) run code about � as fast as a fully compiled
program.  To look into the performance of Java code a number of simple
test routines were run on several machines.  Overall, the performance
was quite good to outstanding.

The program allows you to run four different tests.  These are:

1. A null loop 50,000,000 times.
2. 500,000 sin and 500,000 cos math calculations.
3. A simple array of 5000 doubles is allocated 50,000 times.
4. Load an array of 50,000 points 20 times.

While not a test, the program will also read out the Java Run Time
environment parameters for you.

The Timing Tests.doc and .htm files provide the results from running
the program on a number of machines.  If you provide the results from
your machine I will look at adding it to the report.

You can contact me through SourceForge or my web site at:
http://webpages.charter.net/fred.pospeschil/ 


Fred Pospeschil
2011
  

The SpeedTest1.jar is an executable which can be run if you have
the Java Runtime Environment (JRE) installed.  If you do not have
installed you can get it free for Windows at http://www.java.com/en


The src\ directory contains the Java code for the  program.

This is free and unencumbered software released into the public
domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org/>
